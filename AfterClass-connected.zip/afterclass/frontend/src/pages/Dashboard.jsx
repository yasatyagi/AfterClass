import { useCallback, useEffect, useState } from "react";
import {
  BookOpen, CalendarCheck, CalendarDays, CheckCircle2, Flag, Hash, Home, Loader2,
  LogOut, Megaphone, MessageSquare, RefreshCw, Settings, Sparkles, User, Users, XCircle,
} from "lucide-react";
import toast from "react-hot-toast";
import { Wordmark } from "../components/AuthShell";
import { useAuth } from "../context/AuthContext";
import { getHealth, verifyToken } from "../api";
import { friendlyError, greeting, initials } from "../utils";

const NAV = [
  { group: null, items: [{ label: "Home", icon: Home, active: true }, { label: "My Profile", icon: User }] },
  {
    group: "Academic",
    items: [
      { label: "Archives", icon: BookOpen },
      { label: "Study Studio", icon: Sparkles },
      { label: "Study Groups", icon: Users },
      { label: "Scheduler", icon: CalendarCheck },
    ],
  },
  { group: "Social", items: [{ label: "Messages", icon: MessageSquare }, { label: "Communities", icon: Hash }] },
  { group: "Campus", items: [{ label: "Clubs", icon: Flag }, { label: "Events", icon: CalendarDays }, { label: "Bulletin", icon: Megaphone }] },
  { group: null, items: [{ label: "Settings", icon: Settings }] },
];

function StatusRow({ label, state, detail }) {
  const Icon = state === "ok" ? CheckCircle2 : state === "error" ? XCircle : Loader2;
  return (
    <li className={`status-row ${state}`}>
      <Icon size={18} className={state === "checking" ? "spin" : ""} aria-hidden="true" />
      <div>
        <strong>{label}</strong>
        {detail && <p>{detail}</p>}
      </div>
    </li>
  );
}

export default function Dashboard() {
  const { user, profile, logout, retryProfile } = useAuth();
  const name = profile?.displayName || user.displayName || user.email;
  const firstName = name.split(" ")[0];

  const [checks, setChecks] = useState({ health: { state: "checking" }, verify: { state: "checking" } });

  const runChecks = useCallback(async () => {
    setChecks({ health: { state: "checking" }, verify: { state: "checking" } });
    const [health, verify] = await Promise.allSettled([getHealth(), verifyToken()]);
    setChecks({
      health:
        health.status === "fulfilled"
          ? { state: "ok", detail: `Backend is up (${health.value.service}).` }
          : { state: "error", detail: health.reason.message },
      verify:
        verify.status === "fulfilled"
          ? { state: "ok", detail: `The backend verified your login as ${verify.value.email}.` }
          : { state: "error", detail: verify.reason.message },
    });
  }, []);

  useEffect(() => {
    runChecks();
  }, [runChecks]);

  const onLogout = async () => {
    try {
      await logout();
    } catch (err) {
      toast.error(friendlyError(err));
    }
  };

  const onRetryProfile = async () => {
    try {
      await retryProfile();
    } catch (err) {
      toast.error(friendlyError(err));
    }
  };

  const memberSince = profile?.createdAt?.toDate ? profile.createdAt.toDate().toLocaleDateString() : "Just now";

  return (
    <div className="app">
      <header className="topbar">
        <Wordmark size={18} />
        <div className="topbar-actions">
          <span className="me-btn">
            <span className="avatar sm">{initials(name)}</span>
            {firstName}
          </span>
          <button className="btn btn-sm" onClick={onLogout}><LogOut size={16} />Sign out</button>
        </div>
      </header>

      <div className="layout">
        <aside className="rail-left" aria-label="Primary">
          <div className="me-card">
            <span className="avatar lg">{initials(name)}</span>
            <h3>{name}</h3>
            <p className="muted">{user.email}</p>
          </div>
          <nav aria-label="Main navigation">
            {NAV.map((section, i) => (
              <div className="nav-group" key={i}>
                {section.group && <h4>{section.group}</h4>}
                {section.items.map(({ label, icon: Icon, active }) => (
                  <button
                    key={label}
                    className="nav-item"
                    aria-current={active ? "page" : undefined}
                    disabled={!active}
                    title={active ? undefined : "Coming soon"}
                  >
                    <Icon size={16} aria-hidden="true" />
                    {label}
                    {!active && <span className="soon">Soon</span>}
                  </button>
                ))}
              </div>
            ))}
          </nav>
        </aside>

        <main className="center">
          <section className="card welcome">
            <p className="mono">{new Date().toLocaleDateString(undefined, { weekday: "short", day: "numeric", month: "short", year: "numeric" }).toUpperCase()}</p>
            <h1>{greeting()}, {firstName}.</h1>
            <p className="muted">
              You're signed in and your account is ready. The campus modules in the sidebar are still being built and
              will switch on here as they ship.
            </p>
          </section>

          <section className="card" aria-labelledby="acct-t">
            <h2 id="acct-t">Your account</h2>
            {profile ? (
              <dl className="kv">
                <dt>Name</dt><dd>{profile.displayName}</dd>
                <dt>Email</dt><dd>{profile.email}</dd>
                <dt>Role</dt><dd className="mono">{profile.role}</dd>
                <dt>Member since</dt><dd>{memberSince}</dd>
              </dl>
            ) : (
              <div className="notice error" role="alert">
                <p>We couldn't load your profile from Firestore. Check that Firestore is created and the rules are deployed.</p>
                <button className="btn btn-sm" onClick={onRetryProfile}><RefreshCw size={14} />Try again</button>
              </div>
            )}
          </section>

          <section className="card" aria-labelledby="status-t">
            <div className="card-head">
              <h2 id="status-t">Connection status</h2>
              <button className="btn btn-sm" onClick={runChecks}><RefreshCw size={14} />Re-check</button>
            </div>
            <ul className="status-list">
              <StatusRow label="Firebase sign-in" state="ok" detail={`Signed in as ${user.email}.`} />
              <StatusRow
                label="Firestore profile"
                state={profile ? "ok" : "error"}
                detail={profile ? "Your profile document was read from Firestore." : "Profile document could not be read."}
              />
              <StatusRow label="Backend API reachable" state={checks.health.state} detail={checks.health.detail} />
              <StatusRow label="Backend accepts your login" state={checks.verify.state} detail={checks.verify.detail} />
            </ul>
          </section>
        </main>
      </div>
    </div>
  );
}
