import { createContext, useContext, useEffect, useRef, useState } from "react";
import {
  createUserWithEmailAndPassword,
  onAuthStateChanged,
  sendPasswordResetEmail,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
} from "firebase/auth";
import { doc, getDoc, serverTimestamp, setDoc } from "firebase/firestore";
import { auth, db } from "../firebase";

const AuthContext = createContext(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
};

// Reads users/{uid}; creates it if it doesn't exist yet. The shape matches
// firestore.rules (uid must equal the auth uid, role must be "student").
async function loadOrCreateProfile(user, displayName) {
  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);
  if (snap.exists()) return snap.data();

  const data = {
    uid: user.uid,
    email: user.email,
    displayName: displayName || user.displayName || user.email.split("@")[0],
    role: "student",
    createdAt: serverTimestamp(),
  };
  await setDoc(ref, data);
  return { ...data, createdAt: null };
}

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const registering = useRef(false);

  useEffect(() => {
    if (!auth) {
      setLoading(false);
      return undefined;
    }
    return onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (!firebaseUser) {
        setProfile(null);
        setLoading(false);
        return;
      }
      // register() creates the profile itself with the name the person typed.
      if (registering.current) return;
      try {
        setProfile(await loadOrCreateProfile(firebaseUser));
      } catch (err) {
        console.error("Could not load profile", err);
        setProfile(null);
      } finally {
        setLoading(false);
      }
    });
  }, []);

  const login = (email, password) => signInWithEmailAndPassword(auth, email, password);

  const register = async ({ name, email, password }) => {
    registering.current = true;
    try {
      const cred = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(cred.user, { displayName: name });
      setProfile(await loadOrCreateProfile(cred.user, name));
    } finally {
      registering.current = false;
      setLoading(false);
    }
  };

  const logout = () => signOut(auth);
  const resetPassword = (email) => sendPasswordResetEmail(auth, email);

  const retryProfile = async () => {
    if (!user) return;
    setProfile(await loadOrCreateProfile(user));
  };

  return (
    <AuthContext.Provider
      value={{ user, profile, loading, login, register, logout, resetPassword, retryProfile }}
    >
      {children}
    </AuthContext.Provider>
  );
}
