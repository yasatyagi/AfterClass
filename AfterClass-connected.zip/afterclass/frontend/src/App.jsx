import { Navigate, Route, Routes } from "react-router-dom";
import { firebaseConfigError } from "./firebase";
import { ProtectedRoute, PublicOnlyRoute } from "./components/ProtectedRoute";
import AuthShell from "./components/AuthShell";
import Login from "./pages/Login";
import Register from "./pages/Register";
import ForgotPassword from "./pages/ForgotPassword";
import Dashboard from "./pages/Dashboard";

export default function App() {
  if (firebaseConfigError) {
    return (
      <AuthShell title="Almost there" subtitle="Firebase isn't configured yet.">
        <p className="notice error" role="alert">{firebaseConfigError}</p>
      </AuthShell>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={<PublicOnlyRoute><Login /></PublicOnlyRoute>} />
      <Route path="/register" element={<PublicOnlyRoute><Register /></PublicOnlyRoute>} />
      <Route path="/forgot-password" element={<PublicOnlyRoute><ForgotPassword /></PublicOnlyRoute>} />
      <Route path="/" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}
