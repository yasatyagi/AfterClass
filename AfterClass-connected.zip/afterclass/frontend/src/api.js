import { auth } from "./firebase";

// VITE_API_URL already includes the /api prefix, e.g. http://localhost:8000/api
const BASE = (import.meta.env.VITE_API_URL || "http://localhost:8000/api").replace(/\/$/, "");

/**
 * Call the FastAPI backend. With { authed: true } the signed-in user's Firebase
 * ID token is sent as a Bearer token (Firebase refreshes it automatically).
 */
export async function apiFetch(path, { authed = false, ...options } = {}) {
  const headers = new Headers(options.headers);

  if (authed) {
    const user = auth?.currentUser;
    if (!user) throw new Error("You are not signed in.");
    headers.set("Authorization", `Bearer ${await user.getIdToken()}`);
  }

  let response;
  try {
    response = await fetch(`${BASE}${path}`, { ...options, headers });
  } catch {
    throw new Error(`Cannot reach the API at ${BASE}. Is the backend running, and does FRONTEND_ORIGIN allow this site?`);
  }

  const body = await response.json().catch(() => null);
  if (!response.ok) throw new Error(body?.detail || `Request failed (${response.status})`);
  return body;
}

export const getHealth = () => apiFetch("/health");
export const verifyToken = () => apiFetch("/auth/verify", { authed: true });
