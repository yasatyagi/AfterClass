import React from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import { Toaster } from "react-hot-toast";
import App from "./App";
import { AuthProvider } from "./context/AuthContext";
import "./styles.css";

createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <BrowserRouter>
      <AuthProvider>
        <App />
        <Toaster
          position="top-center"
          toastOptions={{ style: { border: "1.5px solid #29252D", boxShadow: "3px 3px 0 #29252D", color: "#29252D" } }}
        />
      </AuthProvider>
    </BrowserRouter>
  </React.StrictMode>
);
