import { Navigate, useLocation } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export function FullScreenLoader() {
  return (
    <div className="center-screen" role="status" aria-live="polite">
      <Loader2 className="spin" size={28} />
      <span className="sr-only">Loading</span>
    </div>
  );
}

// Signed-out visitors are sent to /login and returned here after signing in.
export function ProtectedRoute({ children }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <FullScreenLoader />;
  if (!user) return <Navigate to="/login" replace state={{ from: location }} />;
  return children;
}

// Login/register pages bounce signed-in users to the dashboard.
export function PublicOnlyRoute({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <FullScreenLoader />;
  if (user) return <Navigate to="/" replace />;
  return children;
}
