export function Wordmark({ size = 20 }) {
  return (
    <div className="wordmark" style={{ fontSize: size }}>
      <span className="mark" aria-hidden="true">aC</span>
      AfterClass
    </div>
  );
}

export default function AuthShell({ title, subtitle, children, footer }) {
  return (
    <main className="auth-page">
      <div className="auth-card">
        <Wordmark size={22} />
        <h1>{title}</h1>
        {subtitle && <p className="muted">{subtitle}</p>}
        {children}
        {footer && <p className="auth-footer">{footer}</p>}
      </div>
    </main>
  );
}
