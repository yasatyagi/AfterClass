import os

import firebase_admin
from dotenv import load_dotenv
from fastapi import FastAPI, Header, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from firebase_admin import auth as firebase_auth

load_dotenv()

if not firebase_admin._apps:
    # Verifying ID tokens only needs the project ID. FIREBASE_PROJECT_ID lets the
    # API run locally without a service-account file. For other Admin features
    # (Firestore, Storage), set GOOGLE_APPLICATION_CREDENTIALS to your
    # service-account JSON. Never commit that file.
    project_id = os.getenv("FIREBASE_PROJECT_ID")
    firebase_admin.initialize_app(options={"projectId": project_id} if project_id else None)

app = FastAPI(title="AfterClass API", version="1.0.0")

# FRONTEND_ORIGIN can hold several origins separated by commas.
_default_origins = "http://localhost:5173,http://127.0.0.1:5173"
origins = [o.strip() for o in os.getenv("FRONTEND_ORIGIN", _default_origins).split(",") if o.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
def root():
    return {"name": "AfterClass API", "status": "running"}


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "afterclass-backend"}


@app.get("/api/auth/verify")
def verify_firebase_token(authorization: str | None = Header(default=None)):
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Missing Firebase ID token")
    token = authorization.removeprefix("Bearer ").strip()
    try:
        decoded = firebase_auth.verify_id_token(token)
        return {"uid": decoded["uid"], "email": decoded.get("email"), "verified": True}
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid or expired Firebase ID token")
