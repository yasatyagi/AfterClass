# AfterClass

React (Vite) frontend + FastAPI backend, with Firebase Auth, Firestore and Hosting.

```
afterclass/
├─ frontend/            React + Vite app (builds to frontend/dist)
├─ backend/             FastAPI service (app/main.py)
├─ firebase.json        Hosting serves frontend/dist; rules deploy from here
├─ firestore.rules
└─ storage.rules
```

## How the pieces connect

1. The browser signs in with **Firebase Auth** (`frontend/src/context/AuthContext.jsx`).
2. Each user gets a profile document at **Firestore** `users/{uid}`, matching `firestore.rules`.
3. For backend calls, `frontend/src/api.js` sends the user's Firebase ID token as `Authorization: Bearer <token>`.
4. **FastAPI** verifies that token with the Firebase Admin SDK (`/api/auth/verify`).
5. `VITE_API_URL` (frontend) points at the backend; `FRONTEND_ORIGIN` (backend) allows the frontend through CORS. These two settings must agree.

## Run locally

You need Node.js LTS, Python 3.11+, and a Firebase project with Email/Password sign-in enabled and Firestore created.

**Terminal 1: backend**
```powershell
cd backend
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1      # macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
copy .env.example .env             # macOS/Linux: cp .env.example .env
# edit .env: set FIREBASE_PROJECT_ID to your Firebase project ID
uvicorn app.main:app --reload --port 8000
```
API docs: http://localhost:8000/docs

**Terminal 2: frontend**
```powershell
cd frontend
copy .env.example .env             # skip if .env already has your Firebase values
npm install
npm run dev
```
Open http://localhost:5173, register an account, and check the **Connection status** card on the dashboard. All four rows should be green.

## Deploy

```powershell
copy .firebaserc.example .firebaserc     # put your real project ID inside
cd frontend; npm install; npm run build; cd ..
firebase deploy --only hosting,firestore:rules,storage
```
Deploy the backend separately (for example Cloud Run), then in the production frontend build set `VITE_API_URL` to the deployed API URL (ending in `/api`) and add the Hosting URL to the backend's `FRONTEND_ORIGIN`.

## Status

- [x] Register, login, password reset, protected dashboard
- [x] Firestore user profile
- [x] Frontend to FastAPI calls with token verification
- [ ] Academic, social and campus modules (sidebar items show "Soon")
